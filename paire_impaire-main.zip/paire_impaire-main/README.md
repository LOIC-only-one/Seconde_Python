# paire_impaire
Programme en .py permettant de dire si un nombre est paire ou impaire.
Execute juste le .exe en .py puis profite !


Do not copyright
