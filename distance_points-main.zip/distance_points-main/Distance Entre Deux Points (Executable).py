﻿#Python3
#Pour executer a partir de la barre, EXECUTER/EXECUTER, ou CTRL+F9
#SQRT((x2-x1)**2+(y2-y1)**2)

from math import *
jeu =True
#Off-st
print('''
    ____  _      __                           ____        _       __
   / __ \(_)____/ /_____ _____  ________     / __ \____  (_)___  / /_
  / / / / / ___/ __/ __ `/ __ \/ ___/ _ \   / /_/ / __ \/ / __ \/ __/
 / /_/ / (__  ) /_/ /_/ / / / / /__/  __/  / ____/ /_/ / / / / / /_
/_____/_/____/\__/\__,_/_/ /_/\___/\___/  /_/    \____/_/_/ /_/\__/
(Loïc Maurer 2nd1)
''')

while jeu:
    #Bras 1 (x2-x1)
    print('---------------------------------')
    FbrasX=float (input("Abscisse de A : ")) #x1
    FbrasY=float (input("Abscisse de B :")) #x2
    FbrasT= FbrasY-FbrasX #Total
    CbrasT= FbrasT**2 # Total aux carré
    print("Le resultat du bras 1 :",CbrasT)
    print('')
    #Bras 2 (y2-y1)
    SbrasX=float (input("Ordonées de A : ")) #y1
    SbrasY=float (input("Ordonées de B :")) #y2
    SbrasT= SbrasY-SbrasX #Total
    SCbrasT= SbrasT**2 # Total aux carré
    print("Le resultat du bras 2 :",SCbrasT)
    print('')
    #Addition Bras1 et Bras2
    AddResult= CbrasT+SCbrasT
    Final= sqrt(AddResult)
    print("Le resultat final de l'addition est de : ", Final)
    print('---------------------------------')
    print('')
