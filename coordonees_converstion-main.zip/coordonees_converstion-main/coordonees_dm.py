import math
jeu = True

print('''
Commande:
red_to_green = Conversion en degré
green_to_red = Conversion en Degré Minute Seconde
''')
while jeu == True:
    answer = input('>>>')

    if answer == "red_to_green":
        degres = float(input('Combien de dégres: '))
        minute = float(input('Combien de minutes: '))
        seconde = float(input('Combien de secondes: '))
    # Ajout de float pour adjoindre les floattants

        answer1 = degres+minute/60+seconde/3600
    # Partie calcul

        print('Les coordonées sont: ',answer1)
    #Answer de red_to_green

    elif answer == "green_to_red":
        valeur_deci = float(input('Entrez votre valeur à convertir (decimal): ')) # 69.3495
        d  = int(valeur_deci)
        print(d)
        m = int((valeur_deci- d)*60)
        print(m)
        s = (valeur_deci - d - m/60)*3600
        print(s)

    else:
        print('Commande introuvable !')